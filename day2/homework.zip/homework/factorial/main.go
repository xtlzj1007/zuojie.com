package main

import "fmt"

func main() {
	fmt.Println(PlusFactorial(5))
}

func Factorial(n int) int {
	if n == 1 {
		return 1
	} else {
		return n * Factorial(n-1)
	}
}

func PlusFactorial(n int) int {
	if n == 1 {
		return 1
	} else {
		return Factorial(n) + PlusFactorial(n-1)
	}
}
