package main

import (
	"math/rand"
	"fmt"
	"time"
)

func main() {
	PrintTenNum()
}

func PrintTenNum() {
	rnd := rand.New(rand.NewSource(time.Now().UnixNano()))
	for i := 0; i < 10; i++ {
		fmt.Println(rnd.Intn(100),rnd.Float32())
	}
}
